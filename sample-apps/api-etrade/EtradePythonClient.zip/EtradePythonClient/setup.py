from distutils.core import setup

setup(
    name='EtradePythonClient',
    version='1.0',
    packages=['etrade_python_client',],
    long_description=open('README.md').read(),
)

